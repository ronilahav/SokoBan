package Model.DB;

import java.io.Serializable;
import java.util.List;

public interface DBM {
	public void saveOrUpdate(DB data);
	//public <T> void deleteData(Class<T> c, Serializable sKey);
	public <T> List<T> getListByQuery(String q);
}
