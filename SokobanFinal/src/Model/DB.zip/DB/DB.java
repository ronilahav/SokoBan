package Model.DB;

public interface DB {

}
